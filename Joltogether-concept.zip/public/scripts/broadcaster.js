const startbtn = document.getElementById('start-stream');
const endbtn = document.getElementById('end-stream');
window.onload = () => {
    startbtn.onclick = () => {
        init();
    }
}

async function init() {
    const stream = await navigator.mediaDevices.getDisplayMedia({
        "audio": true,
        "video": {
            "frameRate": 60
        }
    });
    document.getElementById("video").srcObject = stream;
    const peer = createPeer();
    stream.getTracks().forEach(track => peer.addTrack(track, stream));
}


function createPeer() {
    const peer = new RTCPeerConnection({
        iceServers: [
            {
                urls: "stun:stun.hide.me"
            }
        ]
    });
    peer.onnegotiationneeded = () => handleNegotiationNeededEvent(peer);
    return peer;
}

async function handleNegotiationNeededEvent(peer) {
    const offer = await peer.createOffer();
    await peer.setLocalDescription(offer);
    const payload = {
        sdp: peer.localDescription
    };

    const { data } = await axios.post('/broadcast', payload);
    const desc = new RTCSessionDescription(data.sdp);
    peer.setRemoteDescription(desc).catch(e => console.log(e));
}